from brain_games.games.logics_progression_game import solution_progression_game


def main():
    solution_progression_game()


if __name__ == '__main__':
    main()
