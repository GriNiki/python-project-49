from brain_games.games.logics_calc_game import solution_calc_game


def main():
    solution_calc_game()


if __name__ == '__main__':
    main()
