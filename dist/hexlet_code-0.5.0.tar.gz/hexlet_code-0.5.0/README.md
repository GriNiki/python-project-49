### Hexlet tests and linter status:
[![Actions Status](https://github.com/GriNiki/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/GriNiki/python-project-49/actions)

Пример того как запускать и играть в игру "Brain-even". Это небольшая логическая игра в которой необходимо выбирать четное или нечетное число находится в вопросе.
	https://asciinema.org/a/tzNELFOHiDevzgXLMjWWm5UkZ


Пример того как запускать и играть в игру "Brain-calc". Это небольшая математическая игра в которой необходимо решить небольшие математические примеры и записать правильный ответ.
	https://asciinema.org/a/5UGl20MI9pCJD4cfFeFS8LHoU
	
	
Пример того как запускать и играть в игру "Brain-gcd". Это небольшая математическая игра в которой необходимо решить какой наибольший общий делитель у двух числе.
	https://asciinema.org/a/m2QDG6EVQ8pgzkGzv9zQyBI2b
	
	
Пример того как запускать и играть в игру "Brain-progression". Это небольшая математическая игра в которой необходимо найти правильное пропущенное число арифметической прогрессии.
	https://asciinema.org/a/K7ujdPZLA1A4xiI7ThgnDRwO8
