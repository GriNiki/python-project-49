from brain_games.games.logics_even_game import solution_even_game


def main():
    solution_even_game()


if __name__ == '__main__':
    main()
