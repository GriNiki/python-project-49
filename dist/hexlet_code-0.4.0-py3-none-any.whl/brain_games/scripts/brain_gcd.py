from brain_games.games.logics_gcd_game import solution_game_gcd


def main():
    solution_game_gcd()


if __name__ == '__main__':
    main()
