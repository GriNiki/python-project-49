#!/usr/bin/env python3
from brain_games.cli import greet


def main():
    greet()


if __name__ == '__main__':
    main()
